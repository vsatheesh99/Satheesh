import os
import sys
print (sys.argv)

gFromFile = False 
gFromCC = False 
if len(sys.argv) == 3:
    slotNumber = -1
    cardNumber = -1
    videoFile = "NO- FILE"
    try:
        slotNumber = int(sys.argv[1])
        try:
            cardNumber = int(sys.argv[2])
            gFromCC = True 
        except:
            print ("Exception : 1")
            print (os.path.exists(sys.argv[2]))
            if os.path.exists(sys.argv[2]):
                videoFile = sys.argv[2]
                gFromFile = True
            else:
                Ex = ValueError()
                Ex.strerror = "-"
                raise Ex            
    except:
        print ("Error: Usage <slot Number> <VideoFile/Capture Card Number>.\n\n")

print ('gFromFile:',gFromFile)
print ('gFromCC:',gFromCC)
print (slotNumber, cardNumber, videoFile)
if (gFromCC or gFromFile):
    print ('gFromFile:',gFromFile)
    print ('gFromCC:',gFromCC)
else:
    print ("Quiting")
    sys.exit(-1)    