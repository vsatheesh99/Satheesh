import cv2
import zmq
import base64
import numpy as np

import cv2
import zmq
import time
import atexit
import threading
from imutils.video import VideoStream
from flask import Response, send_file
from flask import Flask
from flask import render_template
import threading
import argparse
import datetime
import imutils
import time
import cv2
import sys
import random
import string
import os
import numpy as np
import shutil
from flask_cors import CORS
import threading 
import os
import zipfile
import subprocess

import socket    
hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)    


if len(sys.argv) == 3:
    try:
        gSlotNumber = int(sys.argv[1])
        try:
            gCardNumber = int(sys.argv[2])
            gFromCC = True 
        except:
            print ("Exception : 1")
            print (os.path.exists(sys.argv[2]))
            if os.path.exists(sys.argv[2]):
                gVideoFile = sys.argv[2]
                gFromFile = True
            else:
                Ex = ValueError()
                Ex.strerror = "-"
                raise Ex            
    except:
        #print ("Error: Usage <slot Number> <VideoFile/Capture Card Number>.\n\n")
        x = 0


app = Flask(__name__)
CORS(app)    

SERVER_HOST = IPAddr

gFrame = ""
def pumpVideo():
    global gFrame
    #videoFile = './samples/k.mp4'
    #videoFile = '/home/venkatesan/Videos/samples/5g.mp4'
    camera = cv2.VideoCapture(gVideoFile)  # init the camera

    timeData = []
    tFlag = True
    prevTime = time.time()
    sleepTime = 0
    skipThr = 0
    skipCnt = 0

    while True:
        curTime = time.time()
        skipCnt += 1        
        try:
            (grabbed, frame) = camera.read()  # grab the current frame
            #print (grabbed)
            if grabbed:
                gFrame = cv2.resize(frame, (640, 480))  # resize the frame
                #encoded, buffer = cv2.imencode('.jpg', frame)
                #footage_socket.send_pyobj(dict(frame=frame, ts="--")) 
                #time.sleep(0.1)
            else:
                camera = cv2.VideoCapture(gVideoFile)  # init the camera    
                #camera.release()
                #cv2.destroyAllWindows()
                #print ("\n\nBye bye\n")
                #break            

            if 1 and (skipThr <= 0 or skipCnt > skipThr):
                skipCnt = 0
                diff1 = 1000*round(curTime-prevTime, 3)
                
                prevTime = curTime
                
                if diff1 < 27:
                    sleepTime += 0.001
                    #skipThr += 1
                elif diff1 > 37:
                    sleepTime -= 0.001
                    #skipThr -= 1
                
                if sleepTime != 0:
                    time.sleep(sleepTime)
                    x = 0



        except KeyboardInterrupt:
            camera.release()
            cv2.destroyAllWindows()
            print ("\n\nBye bye\n")
            break    



def getVideo():
    # grab global references to the output frame and lock variables
    global gSlotData# global outputFrame, lock
    global gFrame
    # loop over frames from the output stream
    ix = 0
    
    videoServerUrl = 'tcp://{}:{}'.format(SERVER_HOST, 9000)

    context = zmq.Context()
    footage_socket = context.socket(zmq.PULL)
    footage_socket.connect(videoServerUrl)

    while True:
        try:
            #print("Waiting for msg...")
            msg = footage_socket.recv_pyobj()
            ts = msg['ts']
            gFrame = msg['frame']        


            cv2.imshow("image", gFrame)
            cv2.waitKey(1)

#            cv2.imshow("image", frame)
 #           cv2.waitKey(1)

        except KeyboardInterrupt:
            cv2.destroyAllWindows()
            print ("\n\nBye bye\n")
            break


def generate(slotNumber):
    # grab global references to the output frame and lock variables
    global gFrame

    while True:
        (flag, encodedImage) = cv2.imencode(".jpg", gFrame)

        # yield the output frame in the byte format
        yield(b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + 
            bytearray(encodedImage) + b'\r\n')


@app.route("/showPlayer")
def showPlayer():
    return render_template("player.html") 
    


@app.route("/video_feed")
def video_feed():
    slotNumber = "0"
    # return the response generated along with the specific media
    # type (mime type)
    print ("================> video_feed")
    return Response(generate(slotNumber), mimetype = "multipart/x-mixed-replace; boundary=frame")


#asd
mainThread = threading.Thread(target=pumpVideo, args=())
mainThread.start()

import atexit

def exitCleanUp():
    mainThread.join()

atexit.register(exitCleanUp)

slotNumber = 1

app.run(host=SERVER_HOST, port=8050+gSlotNumber, debug=True,
    threaded=True, use_reloader=True)    