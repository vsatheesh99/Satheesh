from imutils.video import VideoStream
from flask import Response, send_file
from flask import Flask
from flask import render_template
import threading
import argparse
import datetime
import imutils
import time
import cv2
import random
import string
import os
import numpy as np
import shutil
from flask_cors import CORS
import threading 
import os
import zipfile
import subprocess

import socket    
hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)    
#print("Your Computer Name is:" + hostname)    
#print("Your Computer IP Address is:" + IPAddr)  

#https://www.bluejeans.com/326438094/8946

# To do
"""
MAC ADD of FIRE TV: DC:91:BF:B2:AF:30
Channel Performance
UI navigation performance
Mobile performance
Testing multiple 4 devices (VMS, 3 IPCs) at same time (Functional use case)
  Rack on PROD for DEV Access
PROD monitor
VQA on different prod points
"""

LOG_FILE = './py.log'
#if os.path.exists(LOG_FILE):
#    os.remove(LOG_FILE)
    
fireStickKeyMAP = {
    "UP": 19,
    "DOWN": 20,
    "LEFT": 21,
    "RIGHT": 22,
    "ENTER":66,
    "BACK": 4,
    "HOME": 3,
    "MENU":1,
    "MEDIA": 85,
    "PREV": 88,
    "NEXT":87,
    "POWER":26
}    
    
    
import logging
logging.basicConfig(filename=LOG_FILE,level=logging.DEBUG)
logging.debug('This message should go to the log file')
logging.info('So should this')
logging.warning('And this, too') 

    


FILEPATH = "./temp/"
# initialize the output frame and a lock used to ensure thread-safe
# exchanges of the output frames (useful when multiple browsers/tabs
# are viewing the stream)


# initialize a flask object
app = Flask(__name__)
CORS(app)
# initialize the video stream and allow the camera sensor to
# warmup

NUMBER_OF_SLOTS = 4

gSlotData = {}

for ix in range(0,NUMBER_OF_SLOTS):
    i = str(ix)
    gSlotData[i] = {}
    gSlotData[i]["OutputFrame"]           =  None
    gSlotData[i]["Lock"]                  =  threading.Lock()
    gSlotData[i]["KeyPressed"]            =  "Hello World !!!"
    gSlotData[i]["KeyPressTime"]          =  0
    gSlotData[i]["VideoRecordingStatus"]  =  False
    gSlotData[i]["enableTimeandFrame"]    =  False
    gSlotData[i]["VideoFileGeneration"]   =  False
    gSlotData[i]["VideoPath"]             =  FILEPATH + "videos/slot_" + str(i) + "/"
    gSlotData[i]["VideoFilename"]         =  ""
    gSlotData[i]["VideoFrames"]           =  "" 
    gSlotData[i]["frames"]                =  [] 
    gSlotData[i]["StartFrame"]            =  0 
    gSlotData[i]["EndFrame"]              =  0 
 
if not os.path.exists("./temp/videos/slot_0"): 
    os.mkdir("./temp/videos")
    os.mkdir("./temp/videos/slot_0") 
    
def randomString(stringLength):
    letters = string.ascii_letters
    return ''.join(random.choice(letters) for i in range(stringLength))
 
def zipdir(path, ziph):
    # ziph is zipfile handle
    for root, dirs, files in os.walk(path):
        for file in files:
            ziph.write(os.path.join(root, file))
 
def getTimeStamp():
    retStr = time.strftime("%Y_%m_%d_%H_%M_%S",time.gmtime())
    print ("getTimeStamp:",retStr)
    return retStr

@app.route("/") 
def index():
    # return the rendered template
    return render_template("index.html") 



@app.route("/fireTV") 
def fireTV():
    # return the rendered template
    return render_template("newUI.html") 


def parseSlotInfo(slotStr):
    print ('slotStr:',slotStr)
    try:
        slotStr = slotStr.replace("_Box-",":")
        data = slotStr.split(":")
        data[-1] = str(int(data[-1])-1)
        print ('data:',data)
    except:
        print ("Error")
    data = "0"
    return data


#@app.route("/multishot") 
#def multishot():
#    # return the rendered template
#    return render_template("multipleSlots.html".format(slotNo)) 

@app.route("/slot/<slotNo>") 
def getPage(slotNo):
    # return the rendered template
    return render_template("index_{}.html".format(slotNo)) 


def sendKey(keyCode):
    print("adb", "shell", "input", "keyevent", str(keyCode))
    #result = subprocess.check_output([r"D:\ADB\platform-tools_r30.0.5-windows\platform-tools\adb.exe", "shell", "input", "keyevent", str(keyCode)])
    result = subprocess.check_output(["/home/venkatesan/project/platform-tools_r30.0.5-linux/platform-tools/adb", "shell", "input", "keyevent", str(keyCode)])

    print (result)

@app.route("/sendRemote/<slotNumber>/<key>")
def sendRemote(slotNumber,key):
    print (key)
    retStr = "Success"
    if key in fireStickKeyMAP:
        t1 = threading.Thread(target=sendKey, args=(fireStickKeyMAP[key],))
        t1.start() 
        time.sleep(5)
        t1.join()
        retStr = "Success"
    else:
        retStr = "Key not found in the MAP"
        print("Key not found in the MAP")
    return retStr

def sendRemoteOld(slotNumber,key):  
    global gSlotData, gConfig
    print ("gConfig:",gConfig)  
    if (slotNumber == "0"):
        sendRemoteKey(key)
    gSlotData[slotNumber]["KeyPressTime"] = time.time()
    gSlotData[slotNumber]["KeyPressed"] = key
        
    print ("sendRemote:",slotNumber,key)
    return "Success"

@app.route("/getVideoRecStatus/<slotNumber>/<key>") 
def getVideoRecStatus(slotNumber, key):
    slotNumber = parseSlotInfo(slotNumber)[-1]
    return str(gSlotData[slotNumber]["VideoRecordingStatus"])


@app.route("/startVideoRecording/<slotNumber>/<key>") 
def startVideoRecording(slotNumber, key):  
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    print ("startVideoRecording:",slotNumber,key)
    retStr = ""
    if (1): #with lock:
        if gSlotData[slotNumber]["VideoRecordingStatus"] == False:
            retStr = "Video Recording Started"
            gSlotData[slotNumber]["VideoRecordingStatus"] = True
            if not os.path.exists(gSlotData[slotNumber]["VideoPath"]):
                os.mkdir(gSlotData[slotNumber]["VideoPath"])
            #else:
                #print ("Need to Delete the files")
                #shutil.rmtree(gVideoPath)
            gSlotData[i]["StartFrame"] = time.time()
        else:
            retStr = "Video Recording already in Progress"
    
    return retStr

@app.route("/stopVideoRecording/<slotNumber>/<key>") 
def stopVideoRecording(slotNumber,key):  
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    print ("stopVideoRecording:",slotNumber,key)
    retStr = ""
    
    if (1): #with lock:
        if gSlotData[slotNumber]["VideoRecordingStatus"] == True:
            retStr = "Video Recording Stopped"
            gSlotData[slotNumber]["VideoRecordingStatus"] = False
            gSlotData[slotNumber]["StartFrame"] = 0
        else:
            retStr = "No active Video recording"
    
    return retStr

@app.route("/getLogs/<slotNumber>/<duration>")
def getLogs(slotNumber, duration):
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    print ("getLogs:",slotNumber, duration)
    filePath = r"D:\TensorFlow-Bootcamp\videoStream\test.jpg"
    return download_file(filePath)


@app.route("/getMultiSlotImages/<slotNumberStr>/<duration>")
def getMultiSlotImages(slotNumberStr, duration):
    global gSlotData
    slotNumbers = slotNumberStr.split(",")
    fileList = []
    randZipFile = FILEPATH + "img-slots-"+ "_".join(slotNumbers) + "-" + getTimeStamp() + ".zip"
    for ix in slotNumbers:
        fileName = FILEPATH + "slot-"+ str(ix) + "-" + getTimeStamp() + ".jpg"
        with gSlotData[ix]["Lock"]:
            cv2.imwrite(fileName,  gSlotData[ix]["OutputFrame"])
            fileList.append(fileName)

    with zipfile.ZipFile(randZipFile, 'w') as myzip:
        for fle in fileList:    
            myzip.write(fle)

    for fle in fileList:    
        if os.path.exists(fle):
            os.remove(fle)
            
    print ("getMultiSlotImages:",slotNumberStr,randZipFile)
    return  download_file(randZipFile)


@app.route("/downLoadImages/<slotNumber>/<duration>")
def downLoadImages(slotNumber, duration):
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    
    fileName = FILEPATH + str(slotNumber) + getTimeStamp() + ".jpg"
    with gSlotData[slotNumber]["Lock"]:
        cv2.imwrite(fileName,  gSlotData[slotNumber]["OutputFrame"])

    print ("downLoadImages:",slotNumber,fileName)
    return  download_file(fileName)

@app.route("/downLoadFrames/<slotNumber>/<duration>")
def downLoadFrames(slotNumber, duration):
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    #print (gSlotData)
    frameFile = "Error:No frames Found"    
    with gSlotData[slotNumber]["Lock"]:
        print ('zipf<-:',gSlotData[slotNumber]["VideoFrames"])
        if os.path.exists(gSlotData[slotNumber]["VideoFrames"]):
            frameFile = gSlotData[slotNumber]["VideoFrames"]
            
    print ("downLoadImages:",slotNumber,frameFile)
    if frameFile == "Error:No frames Found":
        return frameFile
    else:
        return  download_file(frameFile)
        
    
@app.route("/downLoadVideo/<slotNumber>/<duration>") 
def downLoadVideo(slotNumber, duration):
    global gSlotData
    slotNumber = parseSlotInfo(slotNumber)[-1]
    print ("downLoadVideo:",slotNumber, duration)
    print ("gVideoFileName:",gSlotData[slotNumber]["VideoFilename"])
    if os.path.exists(gSlotData[slotNumber]["VideoFilename"]):
        return download_file(gSlotData[slotNumber]["VideoFilename"])
    else:
        return "No Recordings"


@app.route("/startMultiSlotVideos/<slotNumberStr>/<duration>")
def startMultiSlotVideos(slotNumberStr, duration):
    global gSlotData
    slotNumbers = slotNumberStr.split(",")
    for ix in slotNumbers:
        startVideoRecording(ix,5)
    return "1"    

@app.route("/stopMultiSlotVideos/<slotNumberStr>/<duration>")
def stopMultiSlotVideos(slotNumberStr, duration):
    global gSlotData
    slotNumbers = slotNumberStr.split(",")
    for ix in slotNumbers:
        stopVideoRecording(ix,5)
    return "1"    



@app.route("/getMultiSlotVideos/<slotNumberStr>/<duration>")
def getMultiSlotVideos(slotNumberStr, duration):
    global gSlotData
    slotNumbers = slotNumberStr.split(",")
    fileList = []
    randZipFile = FILEPATH + "vid-slots-"+ "_".join(slotNumbers) + "-" + getTimeStamp() + ".zip"
    for ix in slotNumbers:
        fileName = gSlotData[ix]["VideoFilename"]
        if os.path.exists(fileName):
            fileList.append(fileName)

    with zipfile.ZipFile(randZipFile, 'w') as myzip:
        for fle in fileList:    
            myzip.write(fle)

    #for fle in fileList:    
    #    if os.path.exists(fle):
    #        os.remove(fle)
            
    print ("getMultiSlotVideos:",slotNumberStr,randZipFile)
    return  download_file(randZipFile)


@app.route("/getMultiSlotFrames/<slotNumberStr>/<duration>")
def getMultiSlotFrames(slotNumberStr, duration):
    global gSlotData
    slotNumbers = slotNumberStr.split(",")
    fileList = []
    randZipFile = FILEPATH + "frm-slots-"+ "_".join(slotNumbers) + "-" + getTimeStamp() + ".zip"
    for ix in slotNumbers:
        fileName = gSlotData[ix]["VideoFrames"]
        if os.path.exists(fileName):
            fileList.append(fileName)

    with zipfile.ZipFile(randZipFile, 'w') as myzip:
        for fle in fileList:    
            myzip.write(fle)

    print ("getMultiSlotVideos:",slotNumberStr,randZipFile)
    return  download_file(randZipFile)


def download_file(filePath):
    print ("sendFile:",filePath)
    return send_file(filePath, as_attachment=True)


def addFrame(img):
    img1 = img.copy()
    h,w,_ = img.shape
    blank_image = np.zeros((h,int(w/2),3), np.uint8)
    img1[0:h,0:int(w/2)] = blank_image
    return img1


def generateVideo(slotNumber, imgList):
    logging.info("Started:generateVideo:{}".format(slotNumber))
    global gSlotData
    #print (gSlotData)
    gSlotData[slotNumber]["VideoFrames"] = FILEPATH + str(slotNumber) + getTimeStamp() + ".zip"
    zipf = zipfile.ZipFile(gSlotData[slotNumber]["VideoFrames"], 'w', zipfile.ZIP_DEFLATED)
    print ('zipf:',zipf)
    framesFolder = gSlotData[slotNumber]["VideoPath"] + randomString(7) + "/"
    
    if not os.path.exists(framesFolder):
        os.mkdir(framesFolder)

    start = time.time()    
    try:
        if(1):#with gSlotData[slotNumber]["Lock"]:
            gSlotData[slotNumber]["VideoFileGeneration"]   =  True
            fps = 30
            height, width, layers = imgList[0].shape
            size = (width,height)
            gSlotData[slotNumber]["VideoFilename"] = gSlotData[slotNumber]["VideoPath"] + randomString(7) + ".avi" 
            
        out = cv2.VideoWriter(gSlotData[slotNumber]["VideoFilename"],cv2.VideoWriter_fourcc(*'DIVX'), fps, size)
        for i in range(len(imgList)):
            # writing to a image array
            out.write(imgList[i])
            cv2.imwrite(framesFolder + "slot{}_frame_{}.jpg".format(slotNumber, i), imgList[i])                
            
        out.release()
        zipdir(framesFolder, zipf)
        zipf.close()
        
    except:
        logging.error("Error while saving the video")
        
    with gSlotData[slotNumber]["Lock"]:
        gSlotData[slotNumber]["VideoFileGeneration"]   =  False
        
    logging.info("Exited:generateVideo:[{}]".format(slotNumber)+":Time taken:" + str(int(time.time()-start)))


def exitCleanUp():
    #print ("Closing the camera")
    print ("Completed")

import atexit
atexit.register(exitCleanUp)


def addRemoteKey(img, txtStr):
    img1 = img.copy()
    
    x,y = 30,80
    w,h = 150,120
    
    fontScale = 1
       
    # Blue color in BGR 
    color = (0, 255, 0) 
      
    # Line thickness of 2 px 
    thickness = 2
    
    #img1[70:70+h,30:30+w] = blank_image
    colour2 = (0,0,0) 
    cv2.rectangle(img1, (x, y), (w, h), (colour2), -1)
    cv2.putText(img1, txtStr , (42,110), cv2.FONT_HERSHEY_SIMPLEX, fontScale, color, thickness, cv2.LINE_AA)
    return img1
    

def addTime(img, txtStr, copy=False):
   
    if copy == True:
        img1 = img.copy()
    else:
        img1 = img
    
    x,y = 30,370
    w,h = 350+200,370+40
    
    #blank_image = np.zeros((h,w,3), np.uint8)
    # fontScale 
    fontScale = 1
       
    # Blue color in BGR 
    color = (0, 0, 255) 
      
    # Line thickness of 2 px 
    thickness = 2
    
    #img1[70:70+h,30:30+w] = blank_image
    colour2 = (0,0,0) 
    #cv2.rectangle(img1, (x, y), (w, h), (colour2), -1)
    cv2.putText(img1, txtStr , (12,100), cv2.FONT_HERSHEY_SIMPLEX, fontScale, color, thickness, cv2.LINE_AA)
    print (txtStr)
    return img1
    
import random
import string
 
def randomString(str_size=12):
    allowed_chars = string.ascii_letters
    return ''.join(random.choice(allowed_chars) for x in range(str_size))
    
gKeys =[]

@app.route('/sendRemoteKey/<remoteKey>')
def sendRemoteKey(remoteKey):
    global gKeys
    gKeys.append(remoteKey.lower())
    return "1" 

@app.route('/getRemoteKey/<id>')
def getRemoteKey(id):
    global gKeys
    key = "NO-KEY#0"

    if len(gKeys) > 0: 
      keyRecv = gKeys.pop(0)
      if 'Platform.Keys.' not in keyRecv:
         keyRecv = 'Platform.Keys.' + keyRecv      
      key = keyRecv + "#" + randomString(4)

    return key 


import cv2
from zmq.asyncio import Context, Poller, ZMQEventLoop
import zmq
import time

def getServerURLs(slotNumber):
    SERVER_HOST = '127.0.0.1'
    SERVER_HOST = '192.168.1.55'
    SERVER_HOST = '192.168.7.200'
    SERVER_HOST = IPAddr
    PORT_START_VALUE = 6000
    SLOT_NUMBER = int(slotNumber)
    videoServerUrl = 'tcp://{}:{}'.format(SERVER_HOST, str(PORT_START_VALUE + SLOT_NUMBER*10))
    cmdServerUrl   = 'tcp://{}:{}'.format(SERVER_HOST, str(PORT_START_VALUE + SLOT_NUMBER*10 + 1))
    return {'videoServerUrl': videoServerUrl, 'cmdServerUrl': cmdServerUrl}


def detect_motion(slotNumber, fileName):
    # grab global references to the video stream, output frame, and
    # lock variables
    global gSlotData
    global cap
    
    #global vs, outputFrame, lock, gVideoFileName
    frameCnt = 0
    imgList = []
    # initialize the motion dete    ````  ctor and the total number of frames
    # read thus far
    #cap = cv2.VideoCapture(fileName) 

    context = zmq.Context()
    src = context.socket(zmq.PULL)
    
    
    urls = getServerURLs(slotNumber)
    src.connect(urls['videoServerUrl'])

    #cmdServer = context.socket(zmq.PUSH)
    #cmdServer.connect("tcp://127.0.0.1:5558")

    #dst = context.socket(zmq.PUSH)
    #dst.connect("tcp://127.0.0.1:5558")

    count = 0
    delay = 0.0
    tFlag = True

    while True:
        msg = src.recv_pyobj()
        ts = msg['ts']
        frame = msg['frame']
        #print (frame.shape, len(frame))    
        if tFlag:
            tFlag = False
            #cv2.imwrite("c:\\temp\\temp.png",frame)
        
        #ACTION = "ACTION"
        #cmdServer.send_pyobj(dict(ACTION="ACTION"))
                    
        with gSlotData[slotNumber]["Lock"]:
            #cv2.putText(frame, gSlotData[slotNumber]["KeyPressed"] , (100,200), cv2.FONT_HERSHEY_SIMPLEX, 5, 2)
            #cv2.putText(frame, str( int(round(time.time() * 1000)%1000000) ), (100,400), cv2.FONT_HERSHEY_SIMPLEX, 5, 2)
            #if gSlotData[slotNumber]["KeyPressed"] != "Hello Raghav !!!":
            #    frame = addFrame(frame)
            try:    
                gSlotData[slotNumber]["OutputFrame"] = frame.copy()
                
                if (time.time()-gSlotData[slotNumber]["KeyPressTime"]) < 30:
                    gSlotData[slotNumber]["OutputFrame"] = addRemoteKey(gSlotData[slotNumber]["OutputFrame"], gSlotData[slotNumber]["KeyPressed"])            
                
                
                if gSlotData[slotNumber]["VideoRecordingStatus"] == True and os.path.exists(gSlotData[slotNumber]["VideoPath"]):
                    frameCnt += 1#print (".")            

                    elapsedTime = int(round((time.time() - gSlotData[slotNumber]["StartFrame"])*1000)) 
                    if 1: #gSlotData[slotNumber]["enableTimeandFrame"] == True:
                        gSlotData[slotNumber]["OutputFrame"] = addTime(gSlotData[slotNumber]["OutputFrame"],\
                                                                       "[{}],[{}:{}]".format(frameCnt,\
                                                                        datetime.datetime.now().strftime("%H:%M:%S"), \
                                                                        int(round(time.time() * 1000)%1000) ))
                                                                        
                    #cv2.putText(gSlotData[slotNumber]["OutputFrame"], str( elapsedTime ), (100,600), cv2.FONT_HERSHEY_SIMPLEX, 5, 2)
                    imgList.append(gSlotData[slotNumber]["OutputFrame"])
                    #print (frameCnt, len(imgList))
                    #cv2.imwrite(gVideoPath + str(int(time.time())) + ".jpg", reSize(outputFrame))
                    if len(imgList) > 500 :
                        imgList = []
                
                if gSlotData[slotNumber]["VideoRecordingStatus"] == False and frameCnt > 0:
                    bgThread = threading.Thread(target=generateVideo, args=(slotNumber,imgList,))
                    bgThread.start() 
                    frameCnt = 0
                    imgList = []    
            except:
                print ("Some unknown Error...")
    total = 0





def generate(slotNumber):
    # grab global references to the output frame and lock variables
    global gSlotData# global outputFrame, lock
    # loop over frames from the output stream
    #slotNumber = "0"
     
    while True:
    
        # wait until the lock is acquired
        with gSlotData[slotNumber]["Lock"]: 
            # check if the output frame is available, otherwise skip
            # the iteration of the loop
            if  gSlotData[slotNumber]["OutputFrame"] is None: 
                continue
            # encode the frame in JPEG format
            (flag, encodedImage) = cv2.imencode(".jpg", gSlotData[slotNumber]["OutputFrame"])
            #print(".")
            # ensure the frame was successfully encoded
            if not flag:
                continue 
               
        # yield the output frame in the byte format
        yield(b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + 
            bytearray(encodedImage) + b'\r\n')
            
            
            

def generateNew():
    encodedImage = cv2.imread(r"D:\TensorFlow-Bootcamp\videoStream\test.jpg")
    print (encodedImage)
    # yield the output frame in the byte format
    return(b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + 
        bytearray(encodedImage) + b'\r\n')

@app.route("/video_feed/<slotNumber>")
def video_feed(slotNumber):
    # return the response generated along with the specific media
    # type (mime type)
    print ("================> video_feed")
    return Response(generate(slotNumber), mimetype = "multipart/x-mixed-replace; boundary=frame")

@app.route("/multiSlot/<randId>")
def multiSlot(randId):
    return render_template("multipleSlots.html") 

gConfig = {}
@app.route("/setConfigCMDs/<slotNumber>/<key>/<value>")
def setConfigCMDs(slotNumber, key, value):
    """send a message every second"""
    global gConfig
    retVal = "-1"
    
    key = key.upper()
    
    if key in ["SCALE", "ACTIVE", "FRAME_RATE"]:    
        urls = getServerURLs(slotNumber)
        ctx = zmq.Context()
        push = ctx.socket(zmq.PUSH)
        push.bind(urls['cmdServerUrl'])
        print ("Sending ", key, value, "to", urls['cmdServerUrl'])
        push.send_pyobj({key : value})
        retVal = "1"

    #poller = Poller()
    #poller.register(pull, zmq.POLLIN)
    #while True:
    #    msg = pull.recv_pyobj()
    #    gConfig['msg'] = msg
    #    print('recvd', msg, gConfig)
    return retVal


# check to see if this is the main thread of execution
if __name__ == '__main__':
    # construct the argument parser and parse command line arguments
    # start a thread that will perform motion detection
    
    movies = [r'E:\Movies\Ant-Man And The Wasp (2018) [WEBRip] [1080p] [YTS.AM]\Ant-Man.And.The.Wasp.2018.1080p.WEBRip.x264-[YTS.AM].mp4',
              r'E:\Movies\Aquaman (2018) [WEBRip] [1080p] [YTS.AM]\Aquaman.2018.1080p.WEBRip.x264-[YTS.AM].mp4',
              r'E:\Movies\Black Panther (2018) [BluRay] [1080p] [YTS.AM]\Black.Panther.2018.1080p.BluRay.x264-[YTS.AM].mp4',
              r'E:\Movies\Doctor Strange (2016) [1080p] [YTS.AG]\Doctor.Strange.2016.1080p.BluRay.x264-[YTS.AG].mp4',
              r'E:\Movies\Fantastic Beasts And Where To Find Them (2016) [1080p] [YTS.AG]\Fantastic.Beasts.And.Where.To.Find.Them.2016.1080p.BluRay.x264-[YTS.AG].mp4',              
    ]
    
    movieStrm = r'D:\TensorFlow-Bootcamp\videoStream\SampleVideo_1280x720_10mb.mp4'
    t = {}
    
    if(1):
        for ix in range(0,NUMBER_OF_SLOTS):
            i = str(ix)
            t[i] = threading.Thread(target=detect_motion, args=(i, movieStrm,))
            t[i].daemon = True
            t[i].start()
            
    #cmdThread = threading.Thread(target=commandServer, args=())    
    #cmdThread.start()            
            
            
    # start the flask app
    app.run(host=IPAddr, port=5005, debug=True,
        threaded=True, use_reloader=True)
        
#C:\Users\J\AppData\Local\Programs\Python\Python35\python.exe 
