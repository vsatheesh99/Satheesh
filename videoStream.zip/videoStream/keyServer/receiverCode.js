var Http = new XMLHttpRequest();
var url='http://192.168.1.200:5005/getRemoteKey';


function randomStr(len, arr) { 
    var ans = ''; 
    for (var i = len; i > 0; i--) { 
        ans +=  
          arr[Math.floor(Math.random() * arr.length)]; 
    } 
    return ans; 
} 

var gLastKey = ''
var gLastId = ''
Http.onreadystatechange = (e) => {
    try{
        //console.log(gLastKey + "$" + gLastId)
        //console.log(Http.responseText)
        keyAndId = Http.responseText.split("#");
        //console.log(keyAndId) 
        if (keyAndId[0] != "NO-KEY" && keyAndId[0] != gLastKey && keyAndId[1] != gLastId) {
            KeyManager.simulateKeyEvent(Platform.Keys.getPlatformKey(eval(keyAndId[0])))
        }
        gLastKey = keyAndId[0]
        gLastId = keyAndId[1]
    }
    catch{
        console.log("Error:While getting the Data");
    }
}

function getRemoteKey(){
    Http.open("GET", url +"/"+randomStr(20,'abcdef1234567'));
    Http.send();
}

setInterval(getRemoteKey, 300);