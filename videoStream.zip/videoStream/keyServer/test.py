# -*- coding: utf-8 -*-
    
from flask import Flask, render_template, request
from werkzeug import secure_filename
import sys, traceback
import pandas as pd
import os
import re
 

#pyarmor pack -e " --onedir --noconsole --icon icon.ico" myfile.py
#pyinstaller --onefile pyServer.py
app = Flask(__name__)


validKeys = """last
enter
pause
exit
left
up
right
down
mic
options
power
menu
power
next 
prev
stop
rew
fwd
play
keyC
keyD
keyA
keyB
record
channelup
channeldown
favorites
PIP
volumeup
volumedown
mute
info
guide
start
menu
widgets
ondemand
dvr
fiostv
hash""".splitlines()

#gKeys = ['Platform.Keys.menu', 'Platform.Keys.menu' , 'Platform.Keys.menu']

gKeys = ['Platform.Keys.'+ key for key in validKeys]
print (gKeys)

import random
import string
 
def randomString(str_size=12):
    allowed_chars = string.ascii_letters
    return ''.join(random.choice(allowed_chars) for x in range(str_size))


@app.route('/SendRemoteKey/<remoteKey>')
def SendRemoteKey(remoteKey):
    global gKeys
    gKeys.append(remoteKey)
    return "1" 

@app.route('/getRemoteKey/<id>')
def getRemoteKey(id):
    global gKeys
    key = "NO-KEY#0"

    if len(gKeys) > 0: 
      keyRecv = gKeys.pop(0)
      if 'Platform.Keys.' not in keyRecv:
         keyRecv = 'Platform.Keys.' + keyRecv      
      key =  + "#" + randomString(4)

    return key 

		
@app.route('/reset')
def reset():
   global gIx     
   gIx = 0
   return "0"

if 1 and  __name__ == "__main__":
    app.run(host='192.168.1.200' , port=5005, debug=True) 
