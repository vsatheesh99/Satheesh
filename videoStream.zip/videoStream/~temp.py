import cv2
import zmq
import time
import atexit
import threading
from imutils.video import VideoStream
from flask import Response, send_file
from flask import Flask
from flask import render_template
import threading
import argparse
import datetime
import imutils
import time
import cv2
import random
import string
import os
import numpy as np
import shutil
from flask_cors import CORS
import threading 
import os
import zipfile
import subprocess


#https://pysource.com/2018/10/31/raspberry-pi-3-and-opencv-3-installation-tutorial/

import os
import sys

CV_CAP_PROP_FRAME_WIDTH = 3
CV_CAP_PROP_FRAME_HEIGHT = 4
CV_CAP_PROP_FPS = 5

gFromFile = False 
gFromCC = False 
gSlotNumber = -1
gCardNumber = -1
gVideoFile = "NO- FILE"
FILEPATH = "./temp/"


gSlotData    = {}
NUMBER_OF_SLOTS = 1    
for ix in range(0,NUMBER_OF_SLOTS):
    i = str(ix)
    gSlotData[i] = {}
    gSlotData[i]["OutputFrame"]           =  None
    gSlotData[i]["Lock"]                  =  threading.Lock()
    gSlotData[i]["KeyPressed"]            =  "Hello World !!!"
    gSlotData[i]["KeyPressTime"]          =  0
    gSlotData[i]["VideoRecordingStatus"]  =  False
    gSlotData[i]["enableTimeandFrame"]    =  False
    gSlotData[i]["VideoFileGeneration"]   =  False
    gSlotData[i]["VideoPath"]             =  FILEPATH + "videos/slot_" + str(i) + "/"
    gSlotData[i]["VideoFilename"]         =  ""
    gSlotData[i]["VideoFrames"]           =  "" 
    gSlotData[i]["frames"]                =  [] 
    gSlotData[i]["StartFrame"]            =  0 
    gSlotData[i]["EndFrame"]              =  0 




if len(sys.argv) == 3:
    try:
        gSlotNumber = int(sys.argv[1])
        try:
            gCardNumber = int(sys.argv[2])
            gFromCC = True 
        except:
            print ("Exception : 1")
            print (os.path.exists(sys.argv[2]))
            if os.path.exists(sys.argv[2]):
                gVideoFile = sys.argv[2]
                gFromFile = True
            else:
                Ex = ValueError()
                Ex.strerror = "-"
                raise Ex            
    except:
        #print ("Error: Usage <slot Number> <VideoFile/Capture Card Number>.\n\n")
        x = 0
"""   
"E:\Movies\Black Panther (2018) [BluRay] [1080p] [YTS.AM]\Black.Panther.2018.1080p.BluRay.x264-[YTS.AM].mp4"
"E:\Movies\Eragon (2006) [1080P]\Eragon.2006.1080p.BrRip.x264.YIFY.mp4"
"""

#print (slotNumber, cardNumber, videoFile)
if (gFromCC or gFromFile):
    print ('gFromFile:',gFromFile)
    print ('gFromCC:',gFromCC)
else:
    print ("\nError: Usage <slot Number> <VideoFile/Capture Card Number>.\n")
    sys.exit(-1)

#from zmq.asyncio import Context, Poller, ZMQEventLoop
#SERVER_HOST = '192.168.7.200'
SERVER_HOST = '192.168.7.6'

PORT_START_VALUE = 6000
SLOT_NUMBER = gSlotNumber
videoServerUrl = 'tcp://{}:{}'.format(SERVER_HOST, (PORT_START_VALUE + SLOT_NUMBER*10))
cmdServerUrl   = 'tcp://{}:{}'.format(SERVER_HOST, (PORT_START_VALUE + SLOT_NUMBER*10 + 1))

print ('videoServerUrl:',videoServerUrl)
print ('cmdServerUrl  :',cmdServerUrl)

IMG_WIDTH  = 1920
IMG_HEIGHT = 1080
FRAME_RATE = 30

gConfig = {
"SCALE" : 35,
"ACTIVE" : True,
"FRAME_RATE":30,
}
def exitCleanUp():
    print ("Closing the camera")
    cap.release()
    cv2.destroyAllWindows()
    #print (timeData)   
    #if mainThres:
    try:
        mainThread.join() 
    except:
        print ("No thread to join")

    print ("Completed")

def reSize(img, scale_percent=25):

    #calculate the 50 percent of original dimensions
    width = int(img.shape[1] * scale_percent / 100)
    height = int(img.shape[0] * scale_percent / 100)

    # dsize
    dsize = (width, height)

    # resize image
    output = cv2.resize(img, dsize)
    return output

atexit.register(exitCleanUp)
#cap = cv2.VideoCapture(0)


if gFromCC == True:
    cap = cv2.VideoCapture(gSlotNumber)
    #cap.set(CV_CAP_PROP_FRAME_WIDTH,1920)
    #cap.set(CV_CAP_PROP_FRAME_HEIGHT,1080)

    #cap.set(CV_CAP_PROP_FPS, 30)
    print("CV_CAP_PROP_FPS:",cap.get(CV_CAP_PROP_FPS))
    
elif gFromFile == True:    
    cap = cv2.VideoCapture(gVideoFile)


#cmdServer = context.socket(zmq.PULL)
#cmdServer.connect("tcp://127.0.0.1:5558")
def mainLoop(cap):

    context = zmq.Context()
    dst = context.socket(zmq.PUSH)
    dst.bind(videoServerUrl)

    print ("Main Loop started...")
    timeData = []
    tFlag = True
    prevTime = time.time()
    sleepTime = 0
    skipThr = 0
    skipCnt = 0
    if(1):#try:
        while True:
            time.sleep(0.03)
            curTime = time.time()
            skipCnt += 1
            if gConfig["ACTIVE"] == True:
                try:
                    ret, frame = cap.read()
                except:
                    ret = False

                if ret ==False and gFromFile == True:    
                    cap = cv2.VideoCapture(gVideoFile)
                    ret, frame = cap.read()
                #print ('ret:',ret)
                
                if gConfig["SCALE"] != 100 and gFromFile == True:
                    frame = reSize(frame, scale_percent = gConfig["SCALE"])
                    #time.sleep(0.01)
                    
                #print (frame.shape, len(frame))    
                
                #if tFlag:
                #    tFlag = False
                #    cv2.imwrite("c:\temp\\temp-1.png",frame)
                
                if ret == True:
                    #print ("Sending...")
                    dst.send_pyobj(dict(frame=frame, ts=time.time()))
                else:
                    print (ret)
            #msg = cmdServer.recv_pyobj()
            #if msg['ACTION'] != "NO_ACTION":
            #    print (msg['ACTION'])
                #timeData.append(1000*round(curTime-prevTime, 3))
                if 0 and (skipThr <= 0 or skipCnt > skipThr):
                    skipCnt = 0
                    diff1 = 1000*round(curTime-prevTime, 3)
                    
                    prevTime = curTime
                    
                    if diff1 < 27:
                        sleepTime += 0.01
                        #skipThr += 1
                    elif diff1 > 37:
                        sleepTime -= 0.01
                        #skipThr -= 1

                    if sleepTime < 0:
                        sleepTime = 0     
                    
                    if sleepTime != 0:

                        if sleepTime > 0:
                            time.sleep(sleepTime)
                        x = 0
                    #print (diff1, sleepTime,"========",skipThr,skipCnt)
            if cv2.waitKey(1) & 0xFF == ord('q'): 
                break
    else:#except:
        print ("Loop breaked")
    print ("Main Loop exited...")

#mainLoop(cap)
#asd
mainThread = threading.Thread(target=mainLoop, args=(cap,))
mainThread.start()


context = zmq.Context()
src = context.socket(zmq.PULL)


#urls = getServerURLs(slotNumber)
src.connect(videoServerUrl)

slotNumber = "0"
while(1):
    try:
        msg = src.recv_pyobj()
        ts = msg['ts']
        gSlotData[slotNumber]["OutputFrame"] = msg['frame']

        # Show the video in a window
        cv2.imshow("Frame", gSlotData[slotNumber]["OutputFrame"])                  # show the frame to our screen
        cv2.waitKey(1)                              # Display it at least one ms
        #                                           # before going to the next frame

    except KeyboardInterrupt:
        cv2.destroyAllWindows()
        print ("\n\nBye bye\n")
        break


# After the loop release the cap object 

# Destroy all the windows 
#cv2.destroyAllWindows()     
    

# initialize the output frame and a lock used to ensure thread-safe
# exchanges of the output frames (useful when multiple browsers/tabs
# are viewing the stream)


# initialize a flask object
app = Flask(__name__)
CORS(app)    


def generate(slotNumber):
    # grab global references to the output frame and lock variables
    global gSlotData# global outputFrame, lock
    # loop over frames from the output stream
    ix = 0



    while True:
    
        # wait until the lock is acquired
        with gSlotData[slotNumber]["Lock"]: 
            # check if the output frame is available, otherwise skip
            # the iteration of the loop

            print ("Receiving...")
            msg = src.recv_pyobj()
            ts = msg['ts']
            gSlotData[slotNumber]["OutputFrame"] = msg['frame']

            if  gSlotData[slotNumber]["OutputFrame"] is None: 
                continue
            # encode the frame in JPEG format
            
            (flag, encodedImage) = cv2.imencode(".jpg", gSlotData[slotNumber]["OutputFrame"])
            if ix > 200:
                fileName = "./temp/temp_{}.png".format(ix)
                print ('fileName:',fileName)
                cv2.imwrite(fileName, gSlotData[slotNumber]["OutputFrame"])


            #print(gSlotData[slotNumber]["OutputFrame"].shape)
            # ensure the frame was successfully encoded
            if not flag:
                continue 
        ix +=1       
        # yield the output frame in the byte format
        yield(b'--frame\r\n' b'Content-Type: image/jpeg\r\n\r\n' + 
            bytearray(encodedImage) + b'\r\n')
            
generate("0")

@app.route("/video_feed")
def video_feed():
    slotNumber = "0"
    # return the response generated along with the specific media
    # type (mime type)
    print ("================> video_feed")
    return Response(generate(slotNumber), mimetype = "multipart/x-mixed-replace; boundary=frame")

slotNumber = 1

#app.run(host="0.0.0.0", port=8000+slotNumber, debug=True,
#    threaded=True, use_reloader=True)