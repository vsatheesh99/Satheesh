import cv2
import zmq
import base64
import time


SERVER_HOST = "192.168.7.6"
videoServerUrl = 'tcp://{}:{}'.format(SERVER_HOST, 9000)

context = zmq.Context()
footage_socket = context.socket(zmq.PUSH)
footage_socket.bind(videoServerUrl)


videoFile = './samples/k.mp4'
camera = cv2.VideoCapture(videoFile)  # init the camera

while True:
    try:
        (grabbed, frame) = camera.read()  # grab the current frame
        #print (grabbed)
        if grabbed:
            frame = cv2.resize(frame, (640, 480))  # resize the frame
            #encoded, buffer = cv2.imencode('.jpg', frame)
            footage_socket.send_pyobj(dict(frame=frame, ts="--")) 
            #time.sleep(0.1)
        else:    
            camera.release()
            cv2.destroyAllWindows()
            print ("\n\nBye bye\n")
            break            
    except KeyboardInterrupt:
        camera.release()
        cv2.destroyAllWindows()
        print ("\n\nBye bye\n")
        break