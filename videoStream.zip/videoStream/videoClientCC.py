import cv2
import zmq
import time
import atexit
import threading

#https://pysource.com/2018/10/31/raspberry-pi-3-and-opencv-3-installation-tutorial/

import os
import sys

CV_CAP_PROP_FRAME_WIDTH = 3
CV_CAP_PROP_FRAME_HEIGHT = 4
CV_CAP_PROP_FPS = 5

gFromFile = False 
gFromCC = False 
gSlotNumber = -1
gCardNumber = -1
gVideoFile = "NO- FILE"

import socket    
hostname = socket.gethostname()    
IPAddr = socket.gethostbyname(hostname)   

if len(sys.argv) == 3:
    try:
        gSlotNumber = int(sys.argv[1])
        try:
            gCardNumber = int(sys.argv[2])
            gFromCC = True 
        except:
            print ("Exception : 1")
            print (os.path.exists(sys.argv[2]))
            if os.path.exists(sys.argv[2]):
                gVideoFile = sys.argv[2]
                gFromFile = True
            else:
                Ex = ValueError()
                Ex.strerror = "-"
                raise Ex            
    except:
        #print ("Error: Usage <slot Number> <VideoFile/Capture Card Number>.\n\n")
        x = 0
"""   
"E:\Movies\Black Panther (2018) [BluRay] [1080p] [YTS.AM]\Black.Panther.2018.1080p.BluRay.x264-[YTS.AM].mp4"
"E:\Movies\Eragon (2006) [1080P]\Eragon.2006.1080p.BrRip.x264.YIFY.mp4"
"""

#print (slotNumber, cardNumber, videoFile)
if (gFromCC or gFromFile):
    print ('gFromFile:',gFromFile)
    print ('gFromCC:',gFromCC)
else:
    print ("\nError: Usage <slot Number> <VideoFile/Capture Card Number>.\n")
    sys.exit(-1)

from zmq.asyncio import Context, Poller, ZMQEventLoop
SERVER_HOST = '192.168.7.200'
SERVER_HOST = IPAddr

PORT_START_VALUE = 6000
SLOT_NUMBER = gSlotNumber
videoServerUrl = 'tcp://{}:{}'.format(SERVER_HOST, (PORT_START_VALUE + SLOT_NUMBER*10))
cmdServerUrl   = 'tcp://{}:{}'.format(SERVER_HOST, (PORT_START_VALUE + SLOT_NUMBER*10 + 1))

print ('videoServerUrl:',videoServerUrl)
print ('cmdServerUrl  :',cmdServerUrl)

IMG_WIDTH  = 1920
IMG_HEIGHT = 1080
FRAME_RATE = 30

gConfig = {
"SCALE" : 35,
"ACTIVE" : True,
"FRAME_RATE":30,
}
def exitCleanUp():
    print ("Closing the camera")
    cap.release()
    cv2.destroyAllWindows()
    print (timeData)    
    print ("Completed")


def commandServer():
    """send a message every second"""
    global gConfig
    global cap
    ctx = zmq.Context()
    pull = ctx.socket(zmq.PULL)
    pull.connect(cmdServerUrl)
    poller = Poller()
    poller.register(pull, zmq.POLLIN)
    while True:
        msg = pull.recv_pyobj()
        print('recvd', msg, gConfig)
        for key in msg:
            value = msg[key]
            if key == "SCALE": 
                value = int(value)
                if value >= 10 and value <= 100:
                    width = int(IMG_WIDTH * value / 100)
                    height = int(IMG_HEIGHT * value / 100)                
                    # Call the API to change the resolution
                    gConfig["SCALE"] = value
                    if gFromCC == True:
                        print ("width:", width, ", height:",height)
                        #cap.set(CV_CAP_PROP_FRAME_WIDTH, width)
                        #cap.set(CV_CAP_PROP_FRAME_HEIGHT, height)
                        cap.set(CV_CAP_PROP_FRAME_WIDTH,1920)
                        cap.set(CV_CAP_PROP_FRAME_HEIGHT,1080)
                        
                    
            if key == "ACTIVE" and (value == "False" or value == "True"):
                gConfig["ACTIVE"] = eval(value)
                


cmdThread = threading.Thread(target=commandServer, args=())    
cmdThread.start()                    


def reSize(img, scale_percent=25):

    #calculate the 50 percent of original dimensions
    width = int(img.shape[1] * scale_percent / 100)
    height = int(img.shape[0] * scale_percent / 100)

    # dsize
    dsize = (width, height)

    # resize image
    output = cv2.resize(img, dsize)
    return output

atexit.register(exitCleanUp)
#cap = cv2.VideoCapture(0)


if gFromCC == True:
    cap = cv2.VideoCapture(gSlotNumber)
    cap.set(CV_CAP_PROP_FRAME_WIDTH,1920)
    cap.set(CV_CAP_PROP_FRAME_HEIGHT,1080)

    #cap.set(CV_CAP_PROP_FPS, 30)
    print("CV_CAP_PROP_FPS:",cap.get(CV_CAP_PROP_FPS))
    
elif gFromFile == True:    
    cap = cv2.VideoCapture(gVideoFile)

context = zmq.Context()
dst = context.socket(zmq.PUSH)
dst.bind(videoServerUrl)

#cmdServer = context.socket(zmq.PULL)
#cmdServer.connect("tcp://127.0.0.1:5558")
timeData = []
tFlag = True
prevTime = time.time()
sleepTime = 0
skipThr = 0
skipCnt = 0
if(1):#try:
    while True:
        #time.sleep(0.03)
        curTime = time.time()
        skipCnt += 1
        if gConfig["ACTIVE"] == True:
            try:
                ret, frame = cap.read()
            except:
                ret = False

            if ret ==False and gFromFile == True:    
                cap = cv2.VideoCapture(gVideoFile)
                ret, frame = cap.read()
            #print ('ret:',ret)
            
            if gConfig["SCALE"] != 100 and gFromFile == True:
                frame = reSize(frame, scale_percent = gConfig["SCALE"])
                #time.sleep(0.01)
                
            #print (frame.shape, len(frame))    
            
            #if tFlag:
            #    tFlag = False
            #    cv2.imwrite("c:\temp\\temp-1.png",frame)
            
            
            if ret == True:
                dst.send_pyobj(dict(frame=frame, ts=time.time()))
            else:
                print (ret)
        #msg = cmdServer.recv_pyobj()
        #if msg['ACTION'] != "NO_ACTION":
        #    print (msg['ACTION'])
            #timeData.append(1000*round(curTime-prevTime, 3))
            if 0 and (skipThr <= 0 or skipCnt > skipThr):
                skipCnt = 0
                diff1 = 1000*round(curTime-prevTime, 3)
                
                prevTime = curTime
                
                if diff1 < 27:
                    sleepTime += 0.001
                    #skipThr += 1
                elif diff1 > 37:
                    sleepTime -= 0.001
                    #skipThr -= 1
                
                if sleepTime != 0:
                    time.sleep(sleepTime)
                    x = 0
                #print (diff1, sleepTime,"========",skipThr,skipCnt)
        if cv2.waitKey(1) & 0xFF == ord('q'): 
            break
else:#except:
    print ("Loop breaked")

    
    
# After the loop release the cap object 

# Destroy all the windows 
#cv2.destroyAllWindows()     
    
    
    
    
