    hostNumber = "0"
   
    serverURL = "http://192.168.7.8:5005/"
     //serverURL = "http://182.65.221.88:5005/"
    
    var gSlotNumber = "Rack_1: Box-1";

    function randomStr(len, arr) { 
        var ans = ''; 
        for (var i = len; i > 0; i--) { 
            ans +=  
              arr[Math.floor(Math.random() * arr.length)]; 
        } 
        return ans; 
    } 

    function sendRemote(slotNumber, key){
        slotNumber = gSlotNumber;
        $.ajax({url: serverURL+"sendRemote/"+slotNumber+"/"+key, success: function(result){
          $("#div1").html(result);
        }});
    }
    
    function ctrlVideoRec(slotNumber) {
        key = randomStr(10,'0123456789abcde')
        slotNumber = gSlotNumber;
        $.ajax({url: serverURL+"getVideoRecStatus/"+slotNumber+"/"+key, success: function(respData){
            if (respData == "False"){
                startVideoRecording(slotNumber);
            }
            else{
                stopVideoRecording(slotNumber);
            }
        }
        });
        
    }

    function startVideoRecording(slotNumber){
        slotNumber = gSlotNumber;
        $.ajax({url: serverURL+"startVideoRecording/"+slotNumber+"/5", success: function(result){
          $("#div1").html(result);
        }});
    }
    
    function stopVideoRecording(slotNumber){
        slotNumber = gSlotNumber;
        $.ajax({url: serverURL+"stopVideoRecording/"+slotNumber+"/6", success: function(result){
          $("#div1").html(result);
        }});
    }    
    

    function getLogs(){
        download("", serverURL + "getLogs/"+hostNumber+"/"); 
    }

    function downLoadImages(slotNumber){
        slotNumber = gSlotNumber;
        randomCode = randomStr(10,'0123456789abcde')
        download("", serverURL + "downLoadImages/"+slotNumber+"/"+randomCode); 
    }
    
    function downLoadVideo(slotNumber){
        slotNumber = gSlotNumber;
        randomCode = randomStr(10,'0123456789abcde')
        download("", serverURL+"downLoadVideo/"+slotNumber+"/" + randomCode); 
    }
    
    function downLoadFrames(slotNumber){
        slotNumber = gSlotNumber;
        randomCode = randomStr(10,'0123456789abcde')
        download("", serverURL+"downLoadFrames/"+slotNumber+"/"+randomCode); 
    }
        
    
    
    function download(file, text) { 
  
        //creating an invisible element 
        var element = document.createElement('a'); 
        //console.debug(encodeURIComponent(text))
        element.setAttribute('href', text); 
        element.setAttribute('download', file); 

        document.body.appendChild(element);  

        //onClick property 
        element.click(); 

        document.body.removeChild(element); 
    } 
